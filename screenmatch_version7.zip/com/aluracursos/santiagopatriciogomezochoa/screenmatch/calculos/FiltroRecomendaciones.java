package com.aluracursos.santiagopatriciogomezochoa.screenmatch.calculos;

public class FiltroRecomendaciones {
    public void filtra(Clasificacion clasificacion){
        if (clasificacion.getClasificacion() >= 4){
            System.out.println("Muy bien evaluado");
        }
        else if (clasificacion.getClasificacion() <= 2) {
            System.out.println("Popular");
        }else{
            System.out.println("Añádelo a tu lista para verlo después");
        }

    }
}
