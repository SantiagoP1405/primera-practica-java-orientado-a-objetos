package com.aluracursos.santiagopatriciogomezochoa.screenmatch.principal;

import com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos.Serie;
import com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos.Titulo;
import com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos.pelicula;

import java.util.ArrayList;

public class PrincipalConListas {
    public static void main(String[] args) {
        pelicula miPelicula = new pelicula("Interestelar" ,2014);
        miPelicula.evalua(9);
        pelicula otraPelicula = new pelicula("Matrix", 1999);
        otraPelicula.evalua(6);
        var peliculaDeSantiago = new pelicula("El Planeta de Los Simios", 2012);
        peliculaDeSantiago.evalua(8);
        Serie casaDragon = new Serie("La casa del dragón", 2022);



        ArrayList<Titulo> lista = new ArrayList<>();
        lista.add(miPelicula);
        lista.add(otraPelicula);
        lista.add(peliculaDeSantiago);
        lista.add(casaDragon);
        
        for (Titulo item:lista){ //foreach
            System.out.println(item.getNombre());
            if (item instanceof pelicula pelicula && pelicula.getClasificacion() > 3){ //¿la instancia es de tipo pelicula? tambien se castea el item para ser de tipo pelicula en lugar de tipo Titulo
                System.out.println(pelicula.getClasificacion());
            }

        }
    }
}
