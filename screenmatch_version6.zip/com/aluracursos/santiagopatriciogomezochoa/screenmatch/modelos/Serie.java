package com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos;

public class Serie extends Titulo{
    //Atributos
    int temporadas;
    int episodiosPorTemporada;
    int minutosPorEpisodios;

    //Constructor
    public Serie(String nombre, int fechaDeLanzamiento) {
        super(nombre, fechaDeLanzamiento);
    }

    //Métodos

    @Override
    public int getDuracionEnMinutos() {
        return temporadas * episodiosPorTemporada * minutosPorEpisodios;
    }

    public int getTemporadas() {
        return temporadas;
    }

    public void setTemporadas(int temporadas) {
        this.temporadas = temporadas;
    }

    public int getEpisodiosPorTemporada() {
        return episodiosPorTemporada;
    }

    public void setEpisodiosPorTemporada(int eposodiosPorTemporada) {
        this.episodiosPorTemporada = eposodiosPorTemporada;
    }

    public int getMinutosPorEpisodios(){
        return minutosPorEpisodios;
    }

    public void setMinutosPorEpisodios(int minutosPorEpisodios) {
        this.minutosPorEpisodios = minutosPorEpisodios;
    }
}
