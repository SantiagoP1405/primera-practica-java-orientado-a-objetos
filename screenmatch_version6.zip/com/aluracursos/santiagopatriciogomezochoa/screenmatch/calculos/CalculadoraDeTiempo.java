package com.aluracursos.santiagopatriciogomezochoa.screenmatch.calculos;
import com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos.Titulo;
import com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos.pelicula;

public class CalculadoraDeTiempo {
    private int tiempoTotal;

    public int getTiempoTotal() {
        return this.tiempoTotal;
    }

    public void incluye(Titulo titulo){
        this.tiempoTotal += titulo.getDuracionEnMinutos();
    }
}
