package com.aluracursos.santiagopatriciogomezochoa.screenmatch.exceptions;

public class ErrorRuntimeException extends RuntimeException {
    private String mensaje;
    public ErrorRuntimeException(String mensaje) {
        this.mensaje = mensaje;
    }

    @Override
    public String getMessage() {
        return this.mensaje;
    }
}
