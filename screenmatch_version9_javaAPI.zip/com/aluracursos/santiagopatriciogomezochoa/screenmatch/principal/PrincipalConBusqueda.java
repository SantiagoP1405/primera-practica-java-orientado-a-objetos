package com.aluracursos.santiagopatriciogomezochoa.screenmatch.principal;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;

public class PrincipalConBusqueda {
    public static void main(String[] args) throws IOException, InterruptedException {
        Scanner input = new Scanner(System.in);
        System.out.println("Escriba el nombre de la película por su título en inglés: ");
        var busqueda = input.nextLine();

        String url = "http://www.omdbapi.com/?t=" + busqueda + "&apikey=98314eb2";
        HttpClient client = HttpClient.newHttpClient(); //Yo pido datos al servidor, soy el cliente
        HttpRequest request = HttpRequest.newBuilder() //U builder sirve para construir algo con muchas formas/características
                .uri(URI.create(url))
                .build();
        HttpResponse<String> response = client
                .send(request, HttpResponse.BodyHandlers.ofString()); //Recibe e interpreta el mensaje. Para send se deben agregar exepciones
        System.out.println(response.body()); //Imprime el Raw json
    }
}
