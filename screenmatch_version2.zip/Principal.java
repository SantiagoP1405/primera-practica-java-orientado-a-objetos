import com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos.pelicula;

public class Principal {
    public static void main(String[] args) {
        pelicula miPelicula = new pelicula(); //Nueva Película
        miPelicula.setNombre("Interestelar");
        miPelicula.setFechaDeLanzamiento(2014);
        miPelicula.setDuracionEnMinutos(169);
        miPelicula.setIncluidoEnElPlan(true);
        miPelicula.muestraFichaTecnica();
        miPelicula.evalua(10);
        miPelicula.evalua(10);
        miPelicula.evalua(7.8);
        System.out.println(miPelicula.getTotalEvaluaciones());
        System.out.println(miPelicula.calculaMedia());

        //System.out.println();

        /*com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos.pelicula otraPelicula = new com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos.pelicula();
        otraPelicula.nombre = "Matrix";
        otraPelicula.fechaDeLanzamiento = 1999;
        otraPelicula.duracionEnMinutos = 150;
        */

    }
}
