package com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos;

import com.aluracursos.santiagopatriciogomezochoa.screenmatch.calculos.Clasificacion;

public class pelicula extends Titulo implements Clasificacion{
    //Atributos
    private String director;

    //Métodos
    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    @Override
    public int getClasificacion() {
        return (int) (calculaMedia() / 2);
    }
}
