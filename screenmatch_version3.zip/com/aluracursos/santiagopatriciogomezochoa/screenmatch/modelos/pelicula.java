package com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos;

public class pelicula extends Titulo{
    //Atributos
    private String director;

    //Métodos
    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }
}
