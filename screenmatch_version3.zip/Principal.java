import com.aluracursos.santiagopatriciogomezochoa.screenmatch.calculos.CalculadoraDeTiempo;
import com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos.Serie;
import com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos.pelicula;

public class Principal {
    public static void main(String[] args) {
        pelicula miPelicula = new pelicula(); //Nueva Película
        miPelicula.setNombre("Interestelar");
        miPelicula.setFechaDeLanzamiento(2014);
        miPelicula.setDuracionEnMinutos(169);
        miPelicula.setIncluidoEnElPlan(true );
        miPelicula.muestraFichaTecnica();
        miPelicula.evalua(10);
        miPelicula.evalua(10);
        miPelicula.evalua(7.8);
        System.out.println(miPelicula.getTotalEvaluaciones());
        System.out.println(miPelicula.calculaMedia());

        Serie casaDragon = new Serie();
        casaDragon.setNombre("La casa del dragón");
        casaDragon.setFechaDeLanzamiento(2022);
        casaDragon.setTemporadas(2);
        casaDragon.setMinutosPorEpisodios(50);
        casaDragon.setEpisodiosPorTemporada(10);
        casaDragon.muestraFichaTecnica();
        System.out.println(casaDragon.getDuracionEnMinutos());

        pelicula otraPelicula = new pelicula();
        otraPelicula.setNombre("Matrix");
        otraPelicula.setFechaDeLanzamiento(1999);
        otraPelicula.setDuracionEnMinutos(150);

        CalculadoraDeTiempo calculadora = new CalculadoraDeTiempo();
        calculadora.incluye(miPelicula);
        calculadora.incluye(casaDragon);
        calculadora.incluye(otraPelicula);
        System.out.println("Tiempo necesario para ve tu lista de títulos: " + calculadora.getTiempoTotal() + " minutos");


        //System.out.println();



    }
}
