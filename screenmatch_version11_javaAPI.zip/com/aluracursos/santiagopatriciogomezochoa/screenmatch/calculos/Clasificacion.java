package com.aluracursos.santiagopatriciogomezochoa.screenmatch.calculos;

public interface Clasificacion {
    int getClasificacion();

}
