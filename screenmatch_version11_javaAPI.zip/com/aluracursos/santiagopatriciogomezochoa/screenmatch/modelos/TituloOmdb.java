package com.aluracursos.santiagopatriciogomezochoa.screenmatch.modelos;

public record TituloOmdb(String title, String year, String runtime) {
}
